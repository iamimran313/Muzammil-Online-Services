# Muzammil Online Service — Latest Android Project

This is the latest Translation Toggle Android project.

## GitHub APK build

The workflow at `.github/workflows/build-apk.yml` builds an installable debug APK using GitHub Actions.

After the workflow finishes successfully, open the workflow run and download the artifact named `Muzammil-Online-Service-debug-apk`.
