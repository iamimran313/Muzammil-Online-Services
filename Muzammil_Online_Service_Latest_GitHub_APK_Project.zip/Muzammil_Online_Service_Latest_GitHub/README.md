# Muzammil Online Service Android v1.2

Added a clear Translation ON/OFF toggle in the top bar.

- OFF: website opens normally; no translation mode is requested.
- ON: translation mode is enabled in the app state and is ready for the translation engine/API.
- The toggle remains available while using the app.

A production automatic translator still needs a translation engine/API or Android-supported translation mechanism to translate arbitrary third-party government pages reliably.
