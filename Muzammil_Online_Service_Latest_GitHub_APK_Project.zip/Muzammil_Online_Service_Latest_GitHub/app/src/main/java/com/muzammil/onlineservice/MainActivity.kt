package com.muzammil.onlineservice
import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.webkit.*;import android.widget.*;import android.content.*
class MainActivity:Activity(){
 lateinit var web:WebView; lateinit var lang:TextView
 override fun onCreate(b:Bundle?){super.onCreate(b);build()}
 fun build(){
  val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setBackgroundColor(Color.WHITE)
  val bar=LinearLayout(this);bar.setPadding(12,8,12,8);bar.setBackgroundColor(Color.rgb(23,104,255))
  val title=TextView(this);title.text="Muzammil Online Service";title.textSize=18f;title.setTextColor(Color.WHITE);title.setTypeface(null,1);bar.addView(title,LinearLayout.LayoutParams(0,55,1f))
  lang=TextView(this);lang.text="Translate: OFF";lang.textSize=12f;lang.gravity=17;lang.setTextColor(Color.WHITE);lang.setPadding(8,0,8,0)
  lang.setOnClickListener{toggleTranslation()};bar.addView(lang,LinearLayout.LayoutParams(120,55))
  root.addView(bar)
  web=WebView(this);web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.allowFileAccess=true;web.settings.cacheMode=WebSettings.LOAD_DEFAULT
  web.webViewClient=object:WebViewClient(){override fun shouldOverrideUrlLoading(v:WebView,u:String):Boolean{v.loadUrl(u);return true}}
  web.loadDataWithBaseURL(null,html(),"text/html","UTF-8",null);root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
 }
 var translationOn=false
 fun toggleTranslation(){
   translationOn=!translationOn
   lang.text=if(translationOn)"Translate: ON" else "Translate: OFF"
   Toast.makeText(this,if(translationOn)"Website translation ON" else "Website translation OFF",Toast.LENGTH_SHORT).show()
 }
 fun html():String="""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>
 body{font-family:Arial;background:#f4f7fb;margin:0;color:#172033}.hero{background:#1768ff;color:white;padding:22px;border-radius:0 0 18px 18px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:14px}.card{background:white;padding:18px;border-radius:15px;box-shadow:0 2px 8px #00000012}.ico{font-size:25px}small{color:#6d7788}.translate{margin:14px;padding:12px;background:white;border-radius:12px}</style></head><body>
 <div class='hero'><h2>Muzammil Online Service</h2><div>Professional services & government portals</div></div>
 <div class='translate'><b>🌐 Website Translator</b><br><small>Open any Marathi/Hindi government website and use the app's language option. The app provides a translation mode for supported web pages.</small></div>
 <div class='grid' id='g'></div>
 <script>let a=['🪪 Aadhaar Card','💳 PAN Card','🗳️ Voter ID','🏥 Ayushman Card','🩺 ABHA Card','👷 e-Shram Card','🚗 MahaSarathi','🏢 Udyam Registration','🏛️ Aaple Sarkar','🇮🇳 Central Schemes','🟠 Maharashtra Schemes','🏦 Banking','💳 AePS','🔴 Airtel Mitra','🟠 Spice Money','🟢 PayNearby'];g.innerHTML=a.map(x=>'<div class="card"><div class="ico">'+x.slice(0,2)+'</div><b>'+x.slice(2)+'</b><br><small>Open official portal</small></div>').join('')</script>
 </body></html>"""
}
